<?php
require 'conexion.php';

$errores = [];
$mensaje = "";

// Obtener ID de la URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID inválido.");
}
$id = (int)$_GET['id'];

// Si se envió el formulario de actualización
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validar datos similares a guardar.php
    if (empty($_POST['nombre'])) {
        $errores[] = "El nombre es obligatorio.";
    } else {
        $nombre = trim($_POST['nombre']);
    }
    if (empty($_POST['email'])) {
        $errores[] = "El correo electrónico es obligatorio.";
    } elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $errores[] = "El correo electrónico no es válido.";
    } else {
        $email = $_POST['email'];
    }
    if (empty($_POST['edad']) || !is_numeric($_POST['edad']) || $_POST['edad'] < 1 || $_POST['edad'] > 120) {
        $errores[] = "La edad debe ser un número entre 1 y 120.";
    } else {
        $edad = (int)$_POST['edad'];
    }
    if (empty($_POST['pais'])) {
        $errores[] = "Debes seleccionar un país.";
    } else {
        $pais = $_POST['pais'];
    }

    if (empty($errores)) {
        $nombre = htmlspecialchars($nombre, ENT_QUOTES, 'UTF-8');
        $email = htmlspecialchars($email, ENT_QUOTES, 'UTF-8');
        $pais = htmlspecialchars($pais, ENT_QUOTES, 'UTF-8');

        $stmt = $conexion->prepare("UPDATE registros SET nombre=?, email=?, edad=?, pais=? WHERE id=?");
        $stmt->bind_param("ssisi", $nombre, $email, $edad, $pais, $id);
        if ($stmt->execute()) {
            $mensaje = "Registro actualizado correctamente.";
        } else {
            if ($conexion->errno == 1062) {
                $mensaje = "El correo electrónico ya está en uso.";
            } else {
                $mensaje = "Error al actualizar: " . $conexion->error;
            }
        }
        $stmt->close();
    }
}

// Obtener datos actuales del registro
$stmt = $conexion->prepare("SELECT nombre, email, edad, pais FROM registros WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$resultado = $stmt->get_result();
if ($resultado->num_rows == 0) {
    die("Registro no encontrado.");
}
$registro = $resultado->fetch_assoc();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Registro</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header id="cabecera">
        <h1>Editar Registro</h1>
    </header>
    <main>
        <section class="formulario">
            <?php if (!empty($errores)): ?>
                <div class="error">
                    <ul>
                        <?php foreach ($errores as $error): ?>
                            <li><?php echo $error; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php elseif ($mensaje): ?>
                <p><?php echo $mensaje; ?></p>
                <p><a href="listar.php">Volver al listado</a></p>
            <?php endif; ?>

            <form action="editar.php?id=<?php echo $id; ?>" method="post">
                <div class="campo">
                    <label for="nombre">Nombre:</label>
                    <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($registro['nombre']); ?>" required>
                </div>
                <div class="campo">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($registro['email']); ?>" required>
                </div>
                <div class="campo">
                    <label for="edad">Edad:</label>
                    <input type="number" id="edad" name="edad" value="<?php echo $registro['edad']; ?>" min="1" max="120" required>
                </div>
                <div class="campo">
                    <label for="pais">País:</label>
                    <select id="pais" name="pais" required>
                        <?php
                        $paises = ['México', 'Colombia', 'Argentina', 'España', 'Estados Unidos', 'Otro'];
                        foreach ($paises as $p) {
                            $selected = ($p == $registro['pais']) ? 'selected' : '';
                            echo "<option value=\"$p\" $selected>$p</option>";
                        }
                        ?>
                    </select>
                </div>
                <button type="submit" class="boton">Actualizar</button>
            </form>
        </section>
    </main>
    <footer>
        <p>&copy; 2025 Actividad 2 Web</p>
    </footer>
</body>
</html>