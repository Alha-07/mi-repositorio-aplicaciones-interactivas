-- Crear la base de datos
CREATE DATABASE IF NOT EXISTS actividad_2_web CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE actividad_2_web;

-- Crear la tabla registros
CREATE TABLE IF NOT EXISTS registros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    edad INT NOT NULL,
    pais VARCHAR(50) NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;