<?php
$servidor = "localhost";
$usuario = "root";
$password = ""; // Contraseña vacía por defecto en XAMPP
$base_datos = "actividad_2_web";

// Crear conexión con mysqli
$conexion = new mysqli($servidor, $usuario, $password, $base_datos);

// Verificar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Establecer codificación de caracteres
$conexion->set_charset("utf8mb4");
?>