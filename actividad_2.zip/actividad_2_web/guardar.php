<?php
require 'conexion.php';

$errores = [];
$nombre = $email = $edad = $pais = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validar campos vacíos
    if (empty($_POST['nombre'])) {
        $errores[] = "El nombre es obligatorio.";
    } else {
        $nombre = trim($_POST['nombre']);
    }

    if (empty($_POST['email'])) {
        $errores[] = "El correo electrónico es obligatorio.";
    } elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $errores[] = "El correo electrónico no es válido.";
    } else {
        $email = $_POST['email'];
    }

    if (empty($_POST['edad'])) {
        $errores[] = "La edad es obligatoria.";
    } elseif (!is_numeric($_POST['edad']) || $_POST['edad'] < 1 || $_POST['edad'] > 120) {
        $errores[] = "La edad debe ser un número entre 1 y 120.";
    } else {
        $edad = (int)$_POST['edad'];
    }

    if (empty($_POST['pais'])) {
        $errores[] = "Debes seleccionar un país.";
    } else {
        $pais = $_POST['pais'];
    }

    // Si no hay errores, proceder a la inserción
    if (empty($errores)) {
        // Sanitizar los datos antes de insertar (aunque usaremos prepared statements)
        $nombre = htmlspecialchars($nombre, ENT_QUOTES, 'UTF-8');
        $email = htmlspecialchars($email, ENT_QUOTES, 'UTF-8');
        $pais = htmlspecialchars($pais, ENT_QUOTES, 'UTF-8');

        // Usar sentencias preparadas para prevenir SQL injection
        $stmt = $conexion->prepare("INSERT INTO registros (nombre, email, edad, pais) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssis", $nombre, $email, $edad, $pais);

        if ($stmt->execute()) {
            $mensaje = "Registro guardado correctamente.";
            $tipo_mensaje = "exito";
        } else {
            // Capturar error de duplicado (email UNIQUE)
            if ($conexion->errno == 1062) {
                $mensaje = "El correo electrónico ya está registrado.";
            } else {
                $mensaje = "Error al guardar el registro: " . $conexion->error;
            }
            $tipo_mensaje = "error";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Resultado del guardado</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header id="cabecera">
        <h1>Resultado de la operación</h1>
    </header>
    <main>
        <section class="formulario">
            <?php if (!empty($errores)): ?>
                <h2>Errores de validación</h2>
                <ul>
                    <?php foreach ($errores as $error): ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <h2><?php echo $mensaje; ?></h2>
            <?php endif; ?>
            <p><a href="index.php">Volver al formulario</a> | <a href="listar.php">Ver registros</a></p>
        </section>
    </main>
    <footer>
        <p>&copy; 2025 Actividad 2 Web</p>
    </footer>
</body>
</html>