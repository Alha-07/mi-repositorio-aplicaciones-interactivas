<?php
require 'conexion.php';

$sql = "SELECT id, nombre, email, edad, pais, fecha_registro FROM registros ORDER BY id DESC";
$resultado = $conexion->query($sql);

if (!$resultado) {
    die("Error en la consulta: " . $conexion->error);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Listado de Registros</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header id="cabecera">
        <h1>Registros almacenados</h1>
    </header>
    <nav class="menu">
        <ul>
            <li><a href="index.php">Nuevo registro</a></li>
        </ul>
    </nav>
    <main>
        <section>
            <article>
                <?php if ($resultado->num_rows > 0): ?>
                    <table class="tabla-registros">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Email</th>
                                <th>Edad</th>
                                <th>País</th>
                                <th>Fecha</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($fila = $resultado->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $fila['id']; ?></td>
                                    <td><?php echo htmlspecialchars($fila['nombre']); ?></td>
                                    <td><?php echo htmlspecialchars($fila['email']); ?></td>
                                    <td><?php echo $fila['edad']; ?></td>
                                    <td><?php echo htmlspecialchars($fila['pais']); ?></td>
                                    <td><?php echo $fila['fecha_registro']; ?></td>
                                    <td class="acciones">
                                        <a href="editar.php?id=<?php echo $fila['id']; ?>">Editar</a>
                                        <a href="eliminar.php?id=<?php echo $fila['id']; ?>" 
                                           onclick="return confirm('¿Seguro que deseas eliminar este registro?');">Eliminar</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No hay registros almacenados.</p>
                <?php endif; ?>
            </article>
        </section>
    </main>
    <footer>
        <p>&copy; 2025 Actividad 2 Web</p>
    </footer>
</body>
</html>
<?php
$conexion->close();
?>