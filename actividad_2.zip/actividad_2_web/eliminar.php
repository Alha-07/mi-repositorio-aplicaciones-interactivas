<?php
require 'conexion.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID inválido.");
}
$id = (int)$_GET['id'];

// Usar sentencia preparada para eliminar solo el registro seleccionado
$stmt = $conexion->prepare("DELETE FROM registros WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    $mensaje = "Registro eliminado correctamente.";
} else {
    $mensaje = "Error al eliminar: " . $conexion->error;
}
$stmt->close();
$conexion->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Eliminar Registro</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header id="cabecera">
        <h1>Eliminar Registro</h1>
    </header>
    <main>
        <section class="formulario">
            <p><?php echo $mensaje; ?></p>
            <p><a href="listar.php">Volver al listado</a></p>
        </section>
    </main>
    <footer>
        <p>&copy; 2025 Actividad 2 Web</p>
    </footer>
</body>
</html>