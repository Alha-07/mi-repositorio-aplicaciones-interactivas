<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuarios</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header id="cabecera">
        <h1>Sistema de Registro</h1>
    </header>
    
    <nav class="menu">
        <ul>
            <li><a href="index.php">Inicio</a></li>
            <li><a href="listar.php">Ver registros</a></li>
        </ul>
    </nav>

    <main>
        <section class="formulario">
            <article>
                <h2>Nuevo registro</h2>
                <form action="guardar.php" method="post">
                    <div class="campo">
                        <label for="nombre">Nombre:</label>
                        <input type="text" id="nombre" name="nombre" required>
                    </div>
                    <div class="campo">
                        <label for="email">Correo electrónico:</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    <div class="campo">
                        <label for="edad">Edad:</label>
                        <input type="number" id="edad" name="edad" min="1" max="120" required>
                    </div>
                    <div class="campo">
                        <label for="pais">País:</label>
                        <select id="pais" name="pais" required>
                            <option value="">Selecciona un país</option>
                            <option value="México">México</option>
                            <option value="Colombia">Colombia</option>
                            <option value="Argentina">Argentina</option>
                            <option value="España">España</option>
                            <option value="Estados Unidos">Estados Unidos</option>
                            <option value="Otro">Otro</option>
                        </select>
                    </div>
                    <button type="submit" class="boton">Guardar registro</button>
                </form>
            </article>
        </section>
    </main>

    <footer>
        <p>&copy; 2026 Actividad 2 Web</p>
    </footer>
</body>
</html>