<?php
$errores = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validar nombre
    if (empty($_POST['nombre'])) {
        $errores[] = "El nombre es obligatorio.";
    } else {
        $nombre = trim(htmlspecialchars($_POST['nombre']));
    }

    // Validar edad
    if (empty($_POST['edad'])) {
        $errores[] = "La edad es obligatoria.";
    } elseif (!is_numeric($_POST['edad'])) {
        $errores[] = "La edad debe ser un número.";
    } else {
        $edad = (int)$_POST['edad'];
    }

    // Validar email
    if (empty($_POST['email'])) {
        $errores[] = "El correo electrónico es obligatorio.";
    } elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $errores[] = "El correo electrónico no es válido.";
    } else {
        $email = htmlspecialchars($_POST['email']);
    }

    // Validar país
    if (empty($_POST['pais'])) {
        $errores[] = "Debes seleccionar un país.";
    } else {
        $pais = htmlspecialchars($_POST['pais']);
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado - Actividad Web</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST" && empty($errores)) {
            // Función personalizada
            function mensajePersonalizado($nombre) {
                return "Hola, " . $nombre . "! Gracias por visitar nuestro sitio.";
            }

            $mensajes = [];
            $mensajes[] = mensajePersonalizado($nombre);
            $mensajes[] = "Nombre: " . $nombre;
            $mensajes[] = "Edad: " . $edad;
            $mensajes[] = "Correo: " . $email;
            $mensajes[] = "País: " . $pais;

            // Validación de mayoría de edad
            if ($edad >= 18) {
                $mensajes[] = "Adult user";
            } else {
                $mensajes[] = "Minor user";
            }

            // Mensajes según el país
            $paises_mensajes = [
                'México' => 'Has seleccionado México, un país lleno de cultura y tradición.',
                'Colombia' => 'Has seleccionado Colombia, tierra del café y la alegría.',
                'Argentina' => 'Has seleccionado Argentina, famosa por el tango y el fútbol.',
                'España' => 'Has seleccionado España, con una historia milenaria.',
                'Estados Unidos' => 'Has seleccionado Estados Unidos, tierra de oportunidades.',
                'Otro' => 'Has seleccionado otro país, ¡qué interesante!'
            ];

            $mensajes[] = isset($paises_mensajes[$pais]) ? $paises_mensajes[$pais] : "País no reconocido.";

            echo "<h2>Resultado del procesamiento</h2>";
            echo "<ul class='resultado-lista'>";
            foreach ($mensajes as $mensaje) {
                echo "<li>" . $mensaje . "</li>";
            }
            echo "</ul>";
        } elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
            echo "<h2>Errores de validación</h2>";
            echo "<ul class='errores-lista'>";
            foreach ($errores as $error) {
                echo "<li>" . $error . "</li>";
            }
            echo "</ul>";
        } else {
            echo "<h2>Acceso no permitido</h2>";
            echo "<p>Debes enviar el formulario.</p>";
        }
        ?>
        <p><a href="index.html">Volver al formulario</a></p>
    </div>
</body>
</html>