// ============================================
// BET OR DIE - Lógica del Juego
// ============================================

// ========== CONFIGURACIÓN ==========
const CONFIG = {
  startingMoney: 1500,
  startingBet: 100,
  baseWinChance: 50,
  baseSpinDuration: 2.0,
  startingDebt: 2000,
  debtIncrease: 200,
  maxDays: 5,
  dayDuration: 10,
  // Mejoras
  luckCost: 150,
  luckIncrease: 8,
  maxLuckLevel: 3,
  speedCost: 100,
  speedDecrease: 0.3,
  maxSpeedLevel: 3,
  betCost: 200,
  betIncrease: 50,
  maxBetLevel: 3,
  // Generadores
  slotCost: 300,
  slotIncome: 30,
  blackjackCost: 800,
  blackjackIncome: 80,
  vipCost: 2000,
  vipIncome: 200
};

// ========== ESTADO DEL JUEGO ==========
const state = {
  money: CONFIG.startingMoney,
  day: 1,
  dayTimeLeft: CONFIG.dayDuration,
  debt: CONFIG.startingDebt,
  isSpinning: false,
  spinDuration: CONFIG.baseSpinDuration,
  winChance: CONFIG.baseWinChance,
  bet: CONFIG.startingBet,
  isPaused: false,
  gameOver: false,
  soundOn: true,
  luckLevel: 0,
  speedLevel: 0,
  betLevel: 0,
  hasSlot: false,
  hasBlackjack: false,
  hasVip: false,
  incomePerSecond: 0,
  lastTick: 0,
  gameLoopId: null
};

// ========== REFERENCIAS DOM ==========
const el = {
  startScreen: document.getElementById('startScreen'),
  gameOverScreen: document.getElementById('gameOverScreen'),
  pauseScreen: document.getElementById('pauseScreen'),
  game: document.getElementById('game'),
  startBtn: document.getElementById('startBtn'),
  restartBtn: document.getElementById('restartBtn'),
  resumeBtn: document.getElementById('resumeBtn'),
  pauseBtn: document.getElementById('pauseBtn'),
  soundBtn: document.getElementById('soundBtn'),
  moneyDisplay: document.getElementById('moneyDisplay'),
  dayDisplay: document.getElementById('dayDisplay'),
  debtDisplay: document.getElementById('debtDisplay'),
  dayProgressBar: document.getElementById('dayProgressBar'),
  debtProgressBar: document.getElementById('debtProgressBar'),
  debtProgressText: document.getElementById('debtProgressText'),
  roulette: document.getElementById('roulette'),
  rouletteWheel: document.querySelector('.roulette-wheel'),
  spinBtn: document.getElementById('spinBtn'),
  spinResult: document.getElementById('spinResult'),
  betDisplay: document.getElementById('betDisplay'),
  chanceDisplay: document.getElementById('chanceDisplay'),
  speedDisplay: document.getElementById('speedDisplay'),
  incomeDisplay: document.getElementById('incomeDisplay'),
  luckLevel: document.getElementById('luckLevel'),
  speedLevel: document.getElementById('speedLevel'),
  betLevel: document.getElementById('betLevel'),
  buyLuck: document.getElementById('buyLuck'),
  buySpeed: document.getElementById('buySpeed'),
  buyBet: document.getElementById('buyBet'),
  buySlot: document.getElementById('buySlot'),
  buyBlackjack: document.getElementById('buyBlackjack'),
  buyVip: document.getElementById('buyVip'),
  messageLog: document.getElementById('messageLog'),
  gameOverTitle: document.getElementById('gameOverTitle'),
  gameOverMessage: document.getElementById('gameOverMessage')
};

// ========== SISTEMA DE SONIDO ==========
let audioCtx = null;

function initAudio() {
  if (!audioCtx) {
    try {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    } catch (e) {
      console.warn('Web Audio API no soportada');
    }
  }
}

function playTone(freq, duration, type = 'sine', volume = 0.08) {
  if (!state.soundOn || !audioCtx) return;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = type;
  osc.frequency.value = freq;
  gain.gain.setValueAtTime(volume, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
  osc.connect(gain);
  gain.connect(audioCtx.destination);
  osc.start();
  osc.stop(audioCtx.currentTime + duration);
}

function sfxSpin() {
  [300, 400, 500, 600].forEach((f, i) => {
    setTimeout(() => playTone(f, 0.08, 'square', 0.04), i * 100);
  });
}
function sfxWin() {
  playTone(523, 0.12);
  setTimeout(() => playTone(659, 0.12), 100);
  setTimeout(() => playTone(784, 0.25), 200);
}
function sfxLose() {
  playTone(300, 0.15, 'sawtooth', 0.06);
  setTimeout(() => playTone(200, 0.3, 'sawtooth', 0.06), 120);
}
function sfxBuy() {
  playTone(800, 0.08);
  setTimeout(() => playTone(1000, 0.12), 70);
}
function sfxGameOver() {
  playTone(400, 0.25, 'sawtooth', 0.08);
  setTimeout(() => playTone(300, 0.25, 'sawtooth', 0.08), 200);
  setTimeout(() => playTone(200, 0.5, 'sawtooth', 0.08), 400);
}

// ========== INICIALIZACIÓN ==========
function initGame() {
  state.money = CONFIG.startingMoney;
  state.day = 1;
  state.dayTimeLeft = CONFIG.dayDuration;
  state.debt = CONFIG.startingDebt;
  state.isSpinning = false;
  state.isPaused = false;
  state.gameOver = false;
  state.luckLevel = 0;
  state.speedLevel = 0;
  state.betLevel = 0;
  state.hasSlot = false;
  state.hasBlackjack = false;
  state.hasVip = false;
  state.winChance = CONFIG.baseWinChance;
  state.spinDuration = CONFIG.baseSpinDuration;
  state.bet = CONFIG.startingBet;
  state.incomePerSecond = 0;
  state.lastTick = performance.now();

  el.spinResult.textContent = '';
  el.spinResult.className = 'spin-result';

  updateUI();
  updateShopUI();
  clearMessages();
  addMessage('💀 Bienvenido a Bet or Die. ¡Gira la ruleta para empezar!');
  addMessage(`📅 Tienes ${CONFIG.maxDays} días para pagar $${CONFIG.startingDebt.toLocaleString()}.`);

  if (state.gameLoopId) cancelAnimationFrame(state.gameLoopId);
  state.gameLoopId = requestAnimationFrame(gameLoop);
}

// ========== BUCLE PRINCIPAL ==========
function gameLoop(timestamp) {
  if (state.gameOver) return;

  if (state.isPaused) {
    state.lastTick = timestamp;
    state.gameLoopId = requestAnimationFrame(gameLoop);
    return;
  }

  const dt = Math.min((timestamp - state.lastTick) / 1000, 0.1);
  state.lastTick = timestamp;

  // Ingreso pasivo
  if (state.incomePerSecond > 0) {
    state.money += state.incomePerSecond * dt;
  }

  // Temporizador del día
  state.dayTimeLeft -= dt;
  if (state.dayTimeLeft <= 0) {
    endDay();
    if (state.gameOver) return;
  }

  updateUI();
  updateDayProgress();

  state.gameLoopId = requestAnimationFrame(gameLoop);
}

// ========== FIN DEL DÍA ==========
function endDay() {
  state.day++;

  if (state.day > CONFIG.maxDays) {
    if (state.money >= state.debt) {
      winGame();
    } else {
      loseGame(`No pudiste pagar la deuda de $${state.debt.toLocaleString()}. La banca siempre gana.`);
    }
    return;
  }

  state.debt += CONFIG.debtIncrease;
  state.dayTimeLeft = CONFIG.dayDuration;

  addMessage(`📅 Día ${state.day} de ${CONFIG.maxDays}. Deuda actual: $${state.debt.toLocaleString()}.`, 'lose');
  playTone(400, 0.2, 'sine', 0.05);
}

// ========== VICTORIA / DERROTA ==========
function winGame() {
  state.gameOver = true;
  cancelAnimationFrame(state.gameLoopId);
  sfxWin();
  el.gameOverTitle.textContent = '🎉 ¡VICTORIA! 🎉';
  el.gameOverTitle.style.color = '#4ade80';
  el.gameOverMessage.textContent = `¡Has pagado la deuda de $${state.debt.toLocaleString()} y sobrevivido al casino! El infierno te teme.`;
  el.gameOverScreen.classList.remove('hidden');
}

function loseGame(reason) {
  state.gameOver = true;
  cancelAnimationFrame(state.gameLoopId);
  sfxGameOver();
  el.gameOverTitle.textContent = '💀 GAME OVER 💀';
  el.gameOverTitle.style.color = '#d90429';
  el.gameOverMessage.textContent = reason;
  el.gameOverScreen.classList.remove('hidden');
}

// ========== GIRAR RULETA ==========
function spinRoulette() {
  if (state.isSpinning || state.gameOver || state.isPaused) return;
  if (state.money < state.bet) {
    addMessage('❌ No tienes suficiente dinero para apostar.', 'lose');
    return;
  }

  initAudio();
  state.isSpinning = true;
  el.rouletteWheel.classList.add('spinning');
  el.spinBtn.disabled = true;
  el.spinResult.textContent = '';
  el.spinResult.className = 'spin-result';

  sfxSpin();
  addMessage(`🎲 Girando la ruleta... Apuesta: $${state.bet}`);

  state.money -= state.bet;
  updateUI();

  const isWin = Math.random() * 100 < state.winChance;

  setTimeout(() => {
    el.rouletteWheel.classList.remove('spinning');

    if (isWin) {
      const winnings = state.bet * 2;
      state.money += winnings;
      el.spinResult.textContent = `🎉 ¡GANASTE $${winnings}!`;
      el.spinResult.classList.add('win');
      sfxWin();
      addMessage(`🎉 ¡Ganaste $${winnings}!`, 'win');
    } else {
      el.spinResult.textContent = `💀 PERDISTE $${state.bet}`;
      el.spinResult.classList.add('lose');
      sfxLose();
      addMessage(`💀 Perdiste $${state.bet}.`, 'lose');
    }

    state.isSpinning = false;
    el.spinBtn.disabled = false;
    updateUI();

    if (state.money < 0) {
      loseGame('Te quedaste sin dinero. La deuda te ha devorado.');
    }
  }, state.spinDuration * 1000);
}

// ========== COMPRAS ==========
function buyLuck() {
  if (state.luckLevel >= CONFIG.maxLuckLevel) return;
  if (state.money < CONFIG.luckCost) { addMessage('❌ No tienes suficiente dinero.', 'lose'); return; }
  state.money -= CONFIG.luckCost;
  state.luckLevel++;
  state.winChance = CONFIG.baseWinChance + state.luckLevel * CONFIG.luckIncrease;
  sfxBuy();
  addMessage(`🍀 Suerte mejorada a ${state.winChance}%.`);
  updateUI(); updateShopUI();
}

function buySpeed() {
  if (state.speedLevel >= CONFIG.maxSpeedLevel) return;
  if (state.money < CONFIG.speedCost) { addMessage('❌ No tienes suficiente dinero.', 'lose'); return; }
  state.money -= CONFIG.speedCost;
  state.speedLevel++;
  state.spinDuration = Math.max(0.5, CONFIG.baseSpinDuration - state.speedLevel * CONFIG.speedDecrease);
  sfxBuy();
  addMessage(`⚡ Velocidad mejorada. Giro en ${state.spinDuration.toFixed(1)}s.`);
  updateUI(); updateShopUI();
}

function buyBet() {
  if (state.betLevel >= CONFIG.maxBetLevel) return;
  if (state.money < CONFIG.betCost) { addMessage('❌ No tienes suficiente dinero.', 'lose'); return; }
  state.money -= CONFIG.betCost;
  state.betLevel++;
  state.bet = CONFIG.startingBet + state.betLevel * CONFIG.betIncrease;
  sfxBuy();
  addMessage(`💵 Apuesta aumentada a $${state.bet}.`);
  updateUI(); updateShopUI();
}

function buySlot() {
  if (state.hasSlot) return;
  if (state.money < CONFIG.slotCost) { addMessage('❌ No tienes suficiente dinero.', 'lose'); return; }
  state.money -= CONFIG.slotCost;
  state.hasSlot = true;
  state.incomePerSecond += CONFIG.slotIncome;
  sfxBuy();
  addMessage(`🎰 ¡Máquina Tragamonedas comprada! +$${CONFIG.slotIncome}/seg.`, 'win');
  updateUI(); updateShopUI();
}

function buyBlackjack() {
  if (state.hasBlackjack) return;
  if (state.money < CONFIG.blackjackCost) { addMessage('❌ No tienes suficiente dinero.', 'lose'); return; }
  state.money -= CONFIG.blackjackCost;
  state.hasBlackjack = true;
  state.incomePerSecond += CONFIG.blackjackIncome;
  sfxBuy();
  addMessage(`🃏 ¡Mesa de Blackjack comprada! +$${CONFIG.blackjackIncome}/seg.`, 'win');
  updateUI(); updateShopUI();
}

function buyVip() {
  if (state.hasVip) return;
  if (state.money < CONFIG.vipCost) { addMessage('❌ No tienes suficiente dinero.', 'lose'); return; }
  state.money -= CONFIG.vipCost;
  state.hasVip = true;
  state.incomePerSecond += CONFIG.vipIncome;
  sfxBuy();
  addMessage(`👑 ¡Sala VIP comprada! +$${CONFIG.vipIncome}/seg.`, 'win');
  updateUI(); updateShopUI();
}

// ========== ACTUALIZACIÓN DE UI ==========
function updateUI() {
  el.moneyDisplay.textContent = `$${Math.floor(state.money).toLocaleString()}`;
  el.dayDisplay.textContent = `${state.day} / ${CONFIG.maxDays}`;
  el.debtDisplay.textContent = `$${state.debt.toLocaleString()}`;
  el.betDisplay.textContent = `$${state.bet}`;
  el.chanceDisplay.textContent = `${state.winChance}%`;
  el.speedDisplay.textContent = `${state.spinDuration.toFixed(1)}s`;
  el.incomeDisplay.textContent = state.incomePerSecond;

  // Color del dinero
  if (state.money < 0) {
    el.moneyDisplay.style.color = '#d90429';
  } else if (state.money >= state.debt) {
    el.moneyDisplay.style.color = '#4ade80';
  } else {
    el.moneyDisplay.style.color = '#d4af37';
  }

  // Barra de deuda
  const progress = Math.min(100, (state.money / state.debt) * 100);
  el.debtProgressBar.style.width = `${Math.max(0, progress)}%`;
  el.debtProgressText.textContent = `${Math.floor(progress)}%`;
  if (progress >= 100) {
    el.debtProgressBar.classList.add('full');
  } else {
    el.debtProgressBar.classList.remove('full');
  }

  // Botón de girar
  el.spinBtn.disabled = state.isSpinning || state.money < state.bet || state.gameOver || state.isPaused;
}

function updateDayProgress() {
  const progress = (state.dayTimeLeft / CONFIG.dayDuration) * 100;
  el.dayProgressBar.style.width = `${Math.max(0, progress)}%`;
}

function updateShopUI() {
  // Suerte
  el.luckLevel.textContent = state.luckLevel;
  const luckMax = state.luckLevel >= CONFIG.maxLuckLevel;
  el.buyLuck.disabled = luckMax || state.money < CONFIG.luckCost;
  el.buyLuck.textContent = luckMax ? 'MAX' : `$${CONFIG.luckCost}`;

  // Velocidad
  el.speedLevel.textContent = state.speedLevel;
  const speedMax = state.speedLevel >= CONFIG.maxSpeedLevel;
  el.buySpeed.disabled = speedMax || state.money < CONFIG.speedCost;
  el.buySpeed.textContent = speedMax ? 'MAX' : `$${CONFIG.speedCost}`;

  // Apuesta
  el.betLevel.textContent = state.betLevel;
  const betMax = state.betLevel >= CONFIG.maxBetLevel;
  el.buyBet.disabled = betMax || state.money < CONFIG.betCost;
  el.buyBet.textContent = betMax ? 'MAX' : `$${CONFIG.betCost}`;

  // Generadores
  el.buySlot.disabled = state.hasSlot || state.money < CONFIG.slotCost;
  el.buySlot.textContent = state.hasSlot ? '✓' : `$${CONFIG.slotCost}`;

  el.buyBlackjack.disabled = state.hasBlackjack || state.money < CONFIG.blackjackCost;
  el.buyBlackjack.textContent = state.hasBlackjack ? '✓' : `$${CONFIG.blackjackCost}`;

  el.buyVip.disabled = state.hasVip || state.money < CONFIG.vipCost;
  el.buyVip.textContent = state.hasVip ? '✓' : `$${CONFIG.vipCost.toLocaleString()}`;
}

function addMessage(text, type = '') {
  const p = document.createElement('p');
  p.className = `message ${type}`;
  p.textContent = text;
  el.messageLog.appendChild(p);
  el.messageLog.scrollTop = el.messageLog.scrollHeight;
  while (el.messageLog.children.length > 20) {
    el.messageLog.removeChild(el.messageLog.firstChild);
  }
}

function clearMessages() {
  el.messageLog.innerHTML = '';
}

// ========== PAUSA ==========
function togglePause() {
  if (state.gameOver) return;
  state.isPaused = !state.isPaused;
  el.pauseBtn.textContent = state.isPaused ? '▶️' : '⏸️';
  el.pauseBtn.title = state.isPaused ? 'Reanudar' : 'Pausar';

  if (state.isPaused) {
    el.pauseScreen.classList.remove('hidden');
    addMessage('⏸️ Juego pausado.');
  } else {
    el.pauseScreen.classList.add('hidden');
    state.lastTick = performance.now();
    addMessage('▶️ Juego reanudado.');
  }
  updateUI();
}

// ========== SONIDO ON/OFF ==========
function toggleSound() {
  state.soundOn = !state.soundOn;
  el.soundBtn.textContent = state.soundOn ? '🔊' : '🔇';
  el.soundBtn.title = state.soundOn ? 'Silenciar' : 'Activar sonido';
}

// ========== EVENTOS ==========
el.startBtn.addEventListener('click', () => {
  initAudio();
  el.startScreen.classList.add('hidden');
  el.game.classList.remove('hidden');
  initGame();
});

el.restartBtn.addEventListener('click', () => {
  el.gameOverScreen.classList.add('hidden');
  el.gameOverTitle.style.color = '#d4af37';
  initGame();
});

el.resumeBtn.addEventListener('click', togglePause);
el.pauseBtn.addEventListener('click', togglePause);
el.soundBtn.addEventListener('click', toggleSound);

el.spinBtn.addEventListener('click', spinRoulette);
el.roulette.addEventListener('click', spinRoulette);

el.buyLuck.addEventListener('click', buyLuck);
el.buySpeed.addEventListener('click', buySpeed);
el.buyBet.addEventListener('click', buyBet);
el.buySlot.addEventListener('click', buySlot);
el.buyBlackjack.addEventListener('click', buyBlackjack);
el.buyVip.addEventListener('click', buyVip);

// Teclado
document.addEventListener('keydown', (e) => {
  if (e.code === 'Space' && !state.isSpinning && !state.gameOver && !state.isPaused) {
    e.preventDefault();
    spinRoulette();
  }
  if (e.code === 'KeyP') togglePause();
  if (e.code === 'KeyM') toggleSound();
});